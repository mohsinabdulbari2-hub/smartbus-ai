import { db } from "@workspace/db";
import {
  busRoutesTable,
  busStopsTable,
  routeStopsTable,
  busFrequencyTable,
} from "@workspace/db";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

// ─── BMTC Official GTFS dataset ──────────────────────────────────────────────
// Source: https://github.com/Vonter/bmtc-gtfs (official BMTC GTFS feed)
// Contains 4,200+ real BMTC routes with correct bus numbers and stop sequences,
// plus 6,000+ unique stops with real lat/lng coordinates.
// ─────────────────────────────────────────────────────────────────────────────

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "..", "..", "lib", "db", "src", "data");

type StopJson = { id: string; name: string; lat: number; lng: number };
type RouteJson = {
  id: string;
  number: string;
  name: string;
  from: string;
  to: string;
  busType: string;
  color: string;
  stops: string[];
};

const stopsJson: StopJson[] = JSON.parse(
  readFileSync(join(DATA_DIR, "bmtc-stops.json"), "utf8")
);
const routesJson: RouteJson[] = JSON.parse(
  readFileSync(join(DATA_DIR, "bmtc-routes.json"), "utf8")
);

// Zone classification by lat/lng (rough Bangalore quadrants around centre 12.9716, 77.5946)
function zoneOf(lat: number, lng: number): string {
  const dLat = lat - 12.9716;
  const dLng = lng - 77.5946;
  const r = Math.sqrt(dLat * dLat + dLng * dLng);
  if (r < 0.04) return "Central";
  if (dLat > 0 && dLng < 0) return "North-West";
  if (dLat > 0 && dLng >= 0) return "North-East";
  if (dLat <= 0 && dLng < 0) return "South-West";
  return "South-East";
}

// Distance estimator using haversine over the route stop sequence
function haversine(a: StopJson, b: StopJson): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * R * Math.asin(Math.sqrt(x));
}

// Reasonable last-bus times by type
const LAST_BUS_BY_TYPE: Record<string, string> = {
  Ordinary: "22:30",
  Vajra: "23:00",
  "Metro Feeder": "22:00",
  Airport: "23:30",
  Volvo: "23:00",
  Night: "05:00",
};

async function main() {
  console.log("🚌 Seeding SmartBus AI from official BMTC GTFS data");
  console.log(`   ${routesJson.length.toLocaleString()} routes, ${stopsJson.length.toLocaleString()} stops`);

  console.log("Clearing existing data...");
  await db.delete(busFrequencyTable);
  await db.delete(routeStopsTable);
  await db.delete(busRoutesTable);
  await db.delete(busStopsTable);

  // ── Stops ─────────────────────────────────────────────────────────────────
  console.log("Inserting stops...");
  const stopRows = stopsJson.map((s) => ({
    id: s.id,
    name: s.name,
    lat: s.lat,
    lng: s.lng,
    zone: zoneOf(s.lat, s.lng),
  }));
  // Batch inserts to avoid parameter limit
  const STOP_BATCH = 500;
  for (let i = 0; i < stopRows.length; i += STOP_BATCH) {
    await db.insert(busStopsTable).values(stopRows.slice(i, i + STOP_BATCH));
  }

  const stopMap = new Map(stopsJson.map((s) => [s.id, s]));

  // ── Routes ────────────────────────────────────────────────────────────────
  console.log("Inserting routes...");
  const routeRows = routesJson.map((r) => {
    let dist = 0;
    for (let i = 1; i < r.stops.length; i++) {
      const a = stopMap.get(r.stops[i - 1]);
      const b = stopMap.get(r.stops[i]);
      if (a && b) dist += haversine(a, b);
    }
    return {
      id: r.id,
      name: r.name || `${r.from} ⇔ ${r.to}`,
      number: r.number,
      from: r.from,
      to: r.to,
      color: r.color,
      totalStops: r.stops.length,
      lastBusTime: LAST_BUS_BY_TYPE[r.busType] || "22:30",
      busType: r.busType,
      depot: null,
      distance: Math.round(dist * 10) / 10,
    };
  });
  const ROUTE_BATCH = 500;
  for (let i = 0; i < routeRows.length; i += ROUTE_BATCH) {
    await db.insert(busRoutesTable).values(routeRows.slice(i, i + ROUTE_BATCH));
  }

  // ── Route ↔ Stop edges ────────────────────────────────────────────────────
  console.log("Inserting route ↔ stop edges...");
  const edges: { routeId: string; stopId: string; order: number }[] = [];
  for (const r of routesJson) {
    r.stops.forEach((sid, idx) => {
      edges.push({ routeId: r.id, stopId: sid, order: idx });
    });
  }
  console.log(`   ${edges.length.toLocaleString()} edges`);
  const EDGE_BATCH = 1000;
  for (let i = 0; i < edges.length; i += EDGE_BATCH) {
    await db.insert(routeStopsTable).values(edges.slice(i, i + EDGE_BATCH));
  }

  // ── Frequency (synthetic, BMTC doesn't publish detailed schedule per route)
  console.log("Inserting bus frequencies...");
  const FREQ_BATCH = 500;
  const freqRows: any[] = [];
  for (const r of routesJson) {
    // Frequency depends on route type — Vajra/Airport = lower, Ordinary = higher
    const base =
      r.busType === "Airport" ? 30 :
      r.busType === "Vajra" ? 20 :
      r.busType === "Metro Feeder" ? 15 :
      10;
    for (const dayType of ["weekday", "weekend"]) {
      const mult = dayType === "weekend" ? 1.4 : 1;
      freqRows.push({
        routeId: r.id,
        dayType,
        morning: Math.round(base * 0.8 * mult),
        afternoon: Math.round(base * 1.2 * mult),
        evening: Math.round(base * 0.7 * mult),
        night: Math.round(base * 2.5 * mult),
      });
    }
  }
  for (let i = 0; i < freqRows.length; i += FREQ_BATCH) {
    await db.insert(busFrequencyTable).values(freqRows.slice(i, i + FREQ_BATCH));
  }

  // ── Stats ─────────────────────────────────────────────────────────────────
  const typeCounts: Record<string, number> = {};
  for (const r of routesJson) typeCounts[r.busType] = (typeCounts[r.busType] || 0) + 1;
  console.log("\n✅ Seed complete!");
  console.log(`   📍 ${stopsJson.length.toLocaleString()} stops`);
  console.log(`   🚌 ${routesJson.length.toLocaleString()} routes`);
  for (const [t, n] of Object.entries(typeCounts)) console.log(`      ${t}: ${n}`);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
